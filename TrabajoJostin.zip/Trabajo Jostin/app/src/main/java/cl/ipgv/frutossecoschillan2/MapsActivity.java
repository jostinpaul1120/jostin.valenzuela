package cl.ipgv.frutossecoschillan2;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import cl.ipgv.frutossecoschillan2.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Ubicacion Actual y de las Sucursales
        LatLng miubicacion = new LatLng(-36.58997719937984, -72.08206983162127);
        LatLng frutodelosbosque1 = new LatLng(-36.59557788856526, -72.10094585925395);
        LatLng frutodelosbosque2 = new LatLng(-36.59551642705443, -72.10691698129241);
        LatLng frutodelosbosque3 = new LatLng(-36.59268914463528, -72.1049266072796);
        LatLng frutodelosbosque4 = new LatLng(-36.59930646201788, -72.09987411934604);

        mMap.addMarker(new MarkerOptions().position(miubicacion).title("Fruto de los bosque"));
        mMap.addMarker(new MarkerOptions().position(frutodelosbosque1).title("Fruto de los bosque"));
        mMap.addMarker(new MarkerOptions().position(frutodelosbosque2).title("Fruto de los bosque"));
        mMap.addMarker(new MarkerOptions().position(frutodelosbosque3).title("Fruto de los bosque"));
        mMap.addMarker(new MarkerOptions().position(frutodelosbosque4).title("Fruto de los bosque"));

        mMap.moveCamera(CameraUpdateFactory.newLatLng(miubicacion));
        mMap.setMinZoomPreference(4.0F);
        mMap.setMaxZoomPreference(18.0F);

    }
}